# manjaro-iso-build

The ISO is split into to files because github cannot handle files larger than 2 GB.

1. Download the `.iso.z01` and the `.iso.zip`
2. Then combine them with `cat [manjaro-mate].iso.z01 [manjaro-mate].iso.zip > manjaro-mate.zip`
3. Now you simply have to unzip the file with `unzip manjaro-mate.zip`
4. **Done** now you have the ISO
